## Arcade game clone

This is a clone of the frogger game for the Udacity front-end nanodegree.

## Motivation

This was the final project for the fend nano degree intermediate-js module.

## Getting started

Serve index.html to your local browser.

### License

Copyright 2017

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

